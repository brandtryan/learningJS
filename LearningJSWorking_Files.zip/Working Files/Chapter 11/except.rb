#num1 = 12
#num2 = 0
#print(num1/num2)
my_file = File.open("afile.txt")