#while comparison
#   statements
#end
#counter = 1
#while counter <= 5
#   puts("hello, world")
#   counter += 1
#end
sum = 0
number = 1
while number < 11
   sum += number
   number += 1
end
puts("the sum is " + sum.to_s)