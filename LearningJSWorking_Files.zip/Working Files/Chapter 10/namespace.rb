require "./Familiar"
require "./Stranger"

print(Familiar.greeting)
print("\n")
print(Stranger.greeting)