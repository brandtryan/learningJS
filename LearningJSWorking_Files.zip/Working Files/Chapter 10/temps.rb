require '.\tempconvert'

puts(ftoc(212))
puts(ctof(0))